const AWS = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand } = require("@aws-sdk/lib-dynamodb");
const bcrypt = require("bcryptjs");

const client = new AWS.DynamoDBClient({});
const dynamoDB = DynamoDBDocumentClient.from(client);

const TABLE_NAME = "Users"; // Ensure this matches DynamoDB table

exports.handler = async (event) => {
    try {
        console.log("Event Received:", JSON.stringify(event)); // Log event for debugging

        const requestBody = JSON.parse(event.body);
        const { username, email, password } = requestBody;

        if (!username || !email || !password) {
            return {
                statusCode: 400,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type",
                },
                body: JSON.stringify({ message: "Missing fields" }),
            };
        }

        // Hash password before storing
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Store user in DynamoDB
        const params = {
            TableName: TABLE_NAME,
            Item: {
                email,
                username,
                password: hashedPassword,
                createdAt: new Date().toISOString(),
            },
        };

        // Ensure DynamoDB request is awaited
        await dynamoDB.send(new PutCommand(params));

        return {
            statusCode: 201,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: "User registered successfully!" }),
        };
    } catch (error) {
        console.error("Lambda Error:", error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
        };
    }
};
